Developer notes
===============

``libmonetdbe.so`` is developed using the MonetDB code repository.

Installation for development
----------------------------

In order to create a version of ``libmonetdbe.so`` do the following:

