*******************
monetdb manual page
*******************

.. include:: manual_pages/monetdb.rst
