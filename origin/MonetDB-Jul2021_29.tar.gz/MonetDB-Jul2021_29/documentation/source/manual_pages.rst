************
Manual pages
************

.. toctree::
   :maxdepth: 0

   man_mclient
   man_msqldump
   man_mserver5
   man_monetdbd
   man_monetdb
