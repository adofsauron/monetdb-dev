*******************
mclient manual page
*******************

.. include:: manual_pages/mclient.rst
